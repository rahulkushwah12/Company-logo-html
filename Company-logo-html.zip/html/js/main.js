


// banner section slider start  
$( document ).ready(function() {
$('.banner-slider').slick({
    centerMode: true,
    arrows:false,
    dots: true,
    autoplay:true,
    speed:500,
    slidesToShow:1,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          slidesToShow: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          slidesToShow: 1
        }
      }
    ]
  });
});

// banner section slider end


// sticky header jquery

$(window).scroll(function(){
  if ($(this).scrollTop() > 300) {
      $('.header').addClass('fixed');
  } else {
      $('.header').removeClass('fixed');
  }
});

// header js start

$( document ).ready(function() {
// div#top-nav
let menuIcon = document.getElementById('nav-icon'); // div#nav-icon [hamburger and close icon, svg] 
let topNav = document.getElementById('top-nav');
// when hamburger icon is clicked
menuIcon.addEventListener('click', function(){
    // div#top-nav add class .nav-active
    topNav.classList.toggle('nav-active');
    // change menu icon from menu-ham-black to menu-close-black.svg (in CSS background)
    menuIcon.classList.toggle('menu-close');
});
});
// header js end


// back to top button jquery 

$(document).ready(() => {
  
  const backToTop = $('#backToTop')
  const amountScrolled = 300
  
  $(window).scroll(() => {
    $(window).scrollTop() >= amountScrolled 
      ? backToTop.fadeIn('fast') 
      : backToTop.fadeOut('fast')
  })
  
  backToTop.click(() => {
    $('body, html').animate({
      scrollTop: 0
    }, 600)
    return false
  })
})

